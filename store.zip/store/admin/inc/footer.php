<footer>
    <div class="pull-right">
        © 2019 | Designed by: K@feel Bh@tti
    </div>
    <div class="clearfix"></div>
</footer>