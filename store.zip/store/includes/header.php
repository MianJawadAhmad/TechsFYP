
<?php require_once 'includes/security.php'; ?>



<!-- Modal1 -->
<?php include 'login.php';?>
<!-- //Modal1 -->
<!-- Modal2 -->
<?php include 'regs.php'?>
<!-- //Modal2 -->