<?php
define("DB_USER", 'localhost');
define("USER", 'root');
define("DB_PASS", '');
define("DB_NAME", 'store');

$conn=mysqli_connect(DB_USER, USER,  DB_PASS, DB_NAME  );

?>